using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Test25.World;
using System;
using System.Collections.Generic;

namespace Test25.Entities
{
    public class Projectile : GameObject
    {
        public float ExplosionRadius { get; set; } = 20f;
        public float Damage { get; set; } = 20f;
        public bool IsDead { get; set; } = false;

        protected Texture2D _texture;

        public Projectile(Vector2 position, Vector2 velocity, Texture2D texture)
        {
            Position = position;
            Velocity = velocity;
            _texture = texture;
        }

        public override void Update(GameTime gameTime)
        {
            // Physics is handled by UpdatePhysics
        }

        public virtual void UpdatePhysics(GameTime gameTime, float wind, float gravity)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            Vector2 v = Velocity;
            v.X += wind * deltaTime;
            v.Y += gravity * deltaTime;
            Velocity = v;

            Position += Velocity * deltaTime;

            if (Velocity.LengthSquared() > 0.1f)
            {
                Rotation = (float)Math.Atan2(Velocity.Y, Velocity.X);
            }
        }

        public virtual bool CheckCollision(Terrain terrain, WallType wallType)
        {
            if (Position.Y > terrain.Height) return true;

            if (wallType == WallType.Solid)
            {
                if (Position.X < 0 || Position.X >= terrain.Width) return true;
            }

            if (Position.X >= 0 && Position.X < terrain.Width)
            {
                if (Position.Y >= terrain.GetHeight((int)Position.X))
                {
                    return true;
                }
            }

            return false;
        }

        public virtual void OnHit(Terrain terrain, List<Tank> players)
        {
            // Default behavior: Explode
            terrain.Destruct((int)Position.X, (int)Position.Y, (int)ExplosionRadius);

            foreach (var player in players)
            {
                if (!player.IsActive) continue;
                float dist = Vector2.Distance(player.Position, Position);
                if (dist < ExplosionRadius + 20) // Simple radius check
                {
                    // Calculate damage based on distance? For now just full damage
                    player.TakeDamage(Damage);
                }
            }

            IsDead = true;
        }

        public override void Draw(SpriteBatch spriteBatch, SpriteFont font)
        {
            if (_texture != null)
            {
                spriteBatch.Draw(_texture, Position, null, Color.White, Rotation, new Vector2(_texture.Width / 2, _texture.Height / 2), 1f, SpriteEffects.None, 0f);
            }
        }
    }
}