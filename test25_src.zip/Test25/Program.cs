﻿// Version: 0.1
using var game = new Test25.Game1();
game.Run();
