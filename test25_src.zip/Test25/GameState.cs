// Version: 0.1
namespace Test25
{
    public enum GameState
    {
        Menu,
        Playing,
        Setup,
        Options,
        Shop
    }
}
